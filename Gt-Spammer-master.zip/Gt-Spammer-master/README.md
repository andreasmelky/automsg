# Gt-Spammer
Growtopia spammer, open source and spam just to the application and also in the latest update you can also choose the application you want to spam and not all applications will work.
You need visual studio 2019 to open and compile this project
